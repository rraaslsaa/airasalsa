<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Siswa extends Model
{
    protected $table = 'siswa';

    protected $fillable = [
        'nis',
        'nama',
        'kelamin',
        'agama',
        'alamat',
        'foto',
        'kelas_id',
    ];

    // Banyak siswa → 1 kelas
    public function kelas()
    {
        return $this->belongsTo(Kelas::class);
    }

    // 1 siswa → banyak pelanggaran
    public function pelanggaran()
    {
        return $this->hasMany(Pelanggaran::class);
    }
}