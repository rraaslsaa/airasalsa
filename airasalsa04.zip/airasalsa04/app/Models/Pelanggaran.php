<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pelanggaran extends Model
{
    protected $table = 'pelanggaran';

    protected $fillable = [
        'foto',
        'tanggal',
        'jenis_id',
        'siswa_id',
        'user_id',
    ];

    // Pelanggaran → Siswa
    public function siswa()
    {
        return $this->belongsTo(Siswa::class);
    }

    // Pelanggaran → Jenis
    public function jenis()
    {
        return $this->belongsTo(Jenis::class);
    }

    // Pelanggaran → User (petugas)
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}