<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Jenis extends Model
{
    protected $table = 'jenis';

    protected $fillable = [
        'jenis',
        'keterangan',
        'poin'
    ];

    // RELASI: 1 jenis memiliki banyak pelanggaran
    public function pelanggaran()
    {
        return $this->hasMany(Pelanggaran::class);
    }
}