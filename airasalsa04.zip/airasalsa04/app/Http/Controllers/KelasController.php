<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use Illuminate\Http\Request;

class KelasController extends Controller
{
    public function index()
    {
        $data = Kelas::all();
        return view('kelas.index', compact('data'));
    }

    public function create()
    {
        return view('kelas.create');
    }

    public function store(Request $r)
    {
        Kelas::create($r->all());
        return redirect('/kelas');
    }

    public function edit($id)
    {
        $data = Kelas::find($id);
        return view('kelas.edit', compact('data'));
    }

    public function update(Request $r, $id)
    {
        Kelas::find($id)->update($r->all());
        return redirect('/kelas');
    }

    public function destroy($id)
    {
        Kelas::find($id)->delete();
        return redirect('/kelas');
    }
}