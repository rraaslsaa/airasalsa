<?php

namespace App\Http\Controllers;

use App\Models\Siswa;
use App\Models\Kelas;
use Illuminate\Http\Request;

class SiswaController extends Controller
{
    public function index()
    {
        $data = Siswa::with('kelas')->get();
        return view('siswa.index', compact('data'));
    }

    public function create()
    {
        return view('siswa.create', [
            'kelas' => Kelas::all()
        ]);
    }

    public function store(Request $r)
    {
        Siswa::create($r->all());
        return redirect('/siswa');
    }

    public function edit($id)
    {
        return view('siswa.edit', [
            'data' => Siswa::find($id),
            'kelas' => Kelas::all()
        ]);
    }

    public function update(Request $r, $id)
    {
        Siswa::find($id)->update($r->all());
        return redirect('/siswa');
    }

    public function destroy($id)
    {
        Siswa::find($id)->delete();
        return redirect('/siswa');
    }
}