<?php

namespace App\Http\Controllers;

use App\Models\Jenis;
use Illuminate\Http\Request;

class JenisController extends Controller
{
    public function index()
    {
        $data = Jenis::all();
        return view('jenis.index', compact('data'));
    }

    public function create()
    {
        return view('jenis.create');
    }

    public function store(Request $r)
    {
        Jenis::create($r->all());
        return redirect('/jenis');
    }

    public function edit($id)
    {
        return view('jenis.edit', [
            'data' => Jenis::find($id)
        ]);
    }

    public function update(Request $r, $id)
    {
        Jenis::find($id)->update($r->all());
        return redirect('/jenis');
    }

    public function destroy($id)
    {
        Jenis::find($id)->delete();
        return redirect('/jenis');
    }
}