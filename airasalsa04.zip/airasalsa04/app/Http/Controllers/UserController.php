<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('user.index', compact('users'));
}

    public function create()
    {
        return view('user.create');
}

    public function store(Request $request)
    {
        $request->validate([
            'username' => 'required|email|unique:users,username',
            'password' => 'required|min:6',
            'nama' => 'required|string|max:100',
            'kelamin' => 'required|string|max:20',
            'alamat' => 'required|string|max:255',
            'level' => 'required|string|max:20',
        ]);

        User::create([
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'nama' => $request->nama,
            'kelamin' => $request->kelamin,
            'alamat' => $request->alamat,
            'level' => $request->level,
        ]);

        return redirect()->route('user.index')->with('success', 'User berhasil ditambahkan!');
}

    public function show(string $id)
    {
        //
}

    public function edit(string $id)
    {
        //
}

    public function update(Request $request, string $id)
    {
        //
}

    public function destroy(string $id)
    {
        //
}
}