<?php

namespace App\Http\Controllers;

use App\Models\Pelanggaran;
use App\Models\Siswa;
use App\Models\Jenis;
use App\Models\User;
use Illuminate\Http\Request;

class PelanggaranController extends Controller
{
    public function index()
    {
        $data = Pelanggaran::with(['siswa','jenis','user'])->get();
        return view('pelanggaran.index', compact('data'));
    }

    public function create()
    {
        return view('pelanggaran.create', [
            'siswa' => Siswa::all(),
            'jenis' => Jenis::all(),
            'user'  => User::all()
        ]);
    }

    public function store(Request $r)
    {
        Pelanggaran::create($r->all());
        return redirect('/pelanggaran');
    }

    public function edit($id)
    {
        return view('pelanggaran.edit', [
            'data'  => Pelanggaran::find($id),
            'siswa' => Siswa::all(),
            'jenis' => Jenis::all(),
            'user'  => User::all()
        ]);
    }

    public function update(Request $r, $id)
    {
        Pelanggaran::find($id)->update($r->all());
        return redirect('/pelanggaran');
    }

    public function destroy($id)
    {
        Pelanggaran::find($id)->delete();
        return redirect('/pelanggaran');
    }
}