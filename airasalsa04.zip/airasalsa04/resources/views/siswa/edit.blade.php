@extends('layout.app')

@section('content')
<div class="container mt-4">

    <div class="card">
        <div class="card-header">Edit Siswa</div>
        <div class="card-body">

            <form action="{{ route('siswa.update', $data->id) }}" method="POST" enctype="multipart/form-data">
                @csrf @method('PUT')

                @if($data->foto)
                    <img src="{{ asset('foto_siswa/'.$data->foto) }}" width="100" class="mb-3">
                @endif

                <label>NIS</label>
                <input type="text" name="nis" value="{{ $data->nis }}" class="form-control">

                <label class="mt-3">Nama</label>
                <input type="text" name="nama" value="{{ $data->nama }}" class="form-control">

                <label class="mt-3">Kelamin</label>
                <select name="kelamin" class="form-control">
                    <option {{ $data->kelamin == 'Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                    <option {{ $data->kelamin == 'Perempuan' ? 'selected' : '' }}>Perempuan</option>
                </select>

                <label class="mt-3">Agama</label>
                <select name="agama" class="form-control">
                    <option {{ $data->agama == 'Islam' ? 'selected' : '' }}>Islam</option>
                    <option {{ $data->agama == 'Kristen' ? 'selected' : '' }}>Kristen</option>
                    <option {{ $data->agama == 'Katholik' ? 'selected' : '' }}>Katholik</option>
                    <option {{ $data->agama == 'Hindu' ? 'selected' : '' }}>Hindu</option>
                    <option {{ $data->agama == 'Buddha' ? 'selected' : '' }}>Buddha</option>
                    <option {{ $data->agama == 'Konghucu' ? 'selected' : '' }}>Konghucu</option>
                </select>

                <label class="mt-3">Alamat</label>
                <textarea name="alamat" class="form-control">{{ $data->alamat }}</textarea>

                <label class="mt-3">Foto Baru</label>
                <input type="file" name="foto" class="form-control">

                <label class="mt-3">Kelas</label>
                <select name="kelas_id" class="form-control">
                    @foreach($kelas as $k)
                    <option value="{{ $k->id }}" {{ $data->kelas_id == $k->id ? 'selected' : '' }}>
                        {{ $k->kelas }}
                    </option>
                    @endforeach
                </select>

                <button class="btn btn-primary mt-3">Update</button>
            </form>

        </div>
    </div>

</div>
@endsection
