@extends('layout.app')

@section('content')
<div class="container mt-4">

    <div class="card">
        <div class="card-header">Tambah Pelanggaran</div>
        <div class="card-body">

            <form action="{{ route('pelanggaran.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <label>Foto</label>
                <input type="file" name="foto" class="form-control">

                <label class="mt-3">Tanggal</label>
                <input type="datetime-local" name="tanggal" class="form-control" required>

                <label class="mt-3">Jenis Pelanggaran</label>
                <select name="jenis_id" class="form-control" required>
                    @foreach($jenis as $j)
                    <option value="{{ $j->id }}">{{ $j->jenis }} ({{ $j->poin }} poin)</option>
                    @endforeach
                </select>

                <label class="mt-3">Siswa</label>
                <select name="siswa_id" class="form-control" required>
                    @foreach($siswa as $s)
                    <option value="{{ $s->id }}">{{ $s->nama }}</option>
                    @endforeach
                </select>

                <button class="btn btn-primary mt-3">Simpan</button>
            </form>

        </div>
    </div>

</div>
@endsection
