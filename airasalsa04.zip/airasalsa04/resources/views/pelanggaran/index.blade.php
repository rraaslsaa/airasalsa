@extends('layout.app')

@section('content')
<div class="container mt-4">

    <a href="{{ route('pelanggaran.create') }}" class="btn btn-primary mb-3">+ Tambah Pelanggaran</a>

    <div class="card">
        <div class="card-header">Data Pelanggaran</div>
        <div class="card-body">

            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Siswa</th>
                    <th>Jenis</th>
                    <th>Tanggal</th>
                    <th>User</th>
                    <th>Aksi</th>
                </tr>

                @foreach($data as $p)
                <tr>
                    <td>{{ $loop->iteration }}</td>

                    <td>
                        @if($p->foto)
                            <img src="{{ asset('foto/'.$p->foto) }}" width="60">
                        @endif
                    </td>

                    <td>{{ $p->siswa->nama }}</td>
                    <td>{{ $p->jenis->jenis }}</td>
                    <td>{{ $p->tanggal }}</td>
                    <td>{{ $p->user->name }}</td>

                    <td>
                        <a href="{{ route('pelanggaran.edit', $p->id) }}" class="btn btn-warning btn-sm">Edit</a>

                        <form action="{{ route('pelanggaran.destroy', $p->id) }}" method="POST" class="d-inline">
                            @csrf @method('DELETE')
                            <button class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
                @endforeach

            </table>

        </div>
    </div>

</div>

@endsection
