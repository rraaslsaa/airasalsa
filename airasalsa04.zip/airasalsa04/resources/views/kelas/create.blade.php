@extends('layout.app')

@section('content')
<div class="container mt-4">

    <div class="card">
        <div class="card-header">Tambah Kelas</div>
        <div class="card-body">

            <form action="{{ route('kelas.store') }}" method="POST">
                @csrf

                <label>Kelas</label>
                <input type="text" name="kelas" class="form-control" required>

                <label class="mt-3">Wali Kelas</label>
                <input type="text" name="walikelas" class="form-control" required>

                <label class="mt-3">Keterangan</label>
                <textarea name="keterangan" class="form-control"></textarea>

                <button class="btn btn-primary mt-3">Simpan</button>
            </form>
        </div>
    </div>

</div>
@endsection
