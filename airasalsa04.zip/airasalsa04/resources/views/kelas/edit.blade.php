@extends('layout.app')

@section('content')
<div class="container mt-4">

    <div class="card">
        <div class="card-header">Edit Kelas</div>
        <div class="card-body">

            <form action="{{ route('kelas.update', $data->id) }}" method="POST">
                @csrf @method('PUT')

                <label>Kelas</label>
                <input type="text" name="kelas" value="{{ $data->kelas }}" class="form-control" required>

                <label class="mt-3">Wali Kelas</label>
                <input type="text" name="walikelas" value="{{ $data->walikelas }}" class="form-control" required>

                <label class="mt-3">Keterangan</label>
                <textarea name="keterangan" class="form-control">{{ $data->keterangan }}</textarea>

                <button class="btn btn-primary mt-3">Update</button>
            </form>

        </div>
    </div>

</div>
@endsection
