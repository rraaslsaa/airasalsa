@extends('layout.app')

@section('content')
<div class="container mt-4">
    <div class="card">
        <div class="card-header">Edit User</div>
        <div class="card-body">
            <form action="{{ route('user.update', $data->id) }}" method="POST">
                @csrf
                @method('PUT')

                <label>Username</label>
                <input type="text" name="username" value="{{ $data->username }}" class="form-control" required>

                <label class="mt-3">Password</label>
                <input type="password" name="password" class="form-control">
                <small class="text-muted">Kosongkan jika tidak ingin mengganti password</small>

                <label class="mt-3">Nama</label>
                <input type="text" name="nama" value="{{ $data->nama }}" class="form-control" required>

                <label class="mt-3">Kelamin</label>
                <select name="kelamin" class="form-control" required>
                    <option value="Laki-laki" {{ $data->kelamin=='Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                    <option value="Perempuan" {{ $data->kelamin=='Perempuan' ? 'selected' : '' }}>Perempuan</option>
                </select>

                <label class="mt-3">Alamat</label>
                <textarea name="alamat" class="form-control">{{ $data->alamat }}</textarea>

                <label class="mt-3">Level</label>
                <select name="level" class="form-control" required>
                    <option value="admin" {{ $data->level=='admin' ? 'selected' : '' }}>admin</option>
                    <option value="petugas" {{ $data->level=='petugas' ? 'selected' : '' }}>petugas</option>
                </select>

                <button class="btn btn-primary mt-3">Update</button>
            </form>
        </div>
    </div>
</div>
@endsection
