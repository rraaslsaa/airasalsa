@extends('layout.app')

@section('content')
<div class="container mt-4">
    <h3>Data User</h3>
    <a href="{{ route('user.create') }}" class="btn btn-primary mb-3">+ Tambah User</a>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Username</th>
            <th>Nama</th>
            <th>Kelamin</th>
            <th>Alamat</th>
            <th>Level</th>
            <th>Aksi</th>
        </tr>

        @foreach($data as $i => $u)
        <tr>
            <td>{{ $i+1 }}</td>
            <td>{{ $u->username }}</td>
            <td>{{ $u->nama }}</td>
            <td>{{ $u->kelamin }}</td>
            <td>{{ $u->alamat }}</td>
            <td>{{ $u->level }}</td>
            <td>
                <a href="{{ route('user.edit', $u->id) }}" class="btn btn-warning btn-sm">Edit</a>
                <form action="{{ route('user.destroy', $u->id) }}" method="POST" class="d-inline">
                    @csrf @method('DELETE')
                    <button class="btn btn-danger btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
</div>
@endsection
