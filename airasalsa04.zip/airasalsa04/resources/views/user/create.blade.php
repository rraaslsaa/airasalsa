@extends('layout.app')

@section('content')
<div class="container mt-4">
    <div class="card">
        <div class="card-header">Tambah User</div>
        <div class="card-body">
            <form action="{{ route('user.store') }}" method="POST">
                @csrf

                <label>Username</label>
                <input type="text" name="username" class="form-control" required>

                <label class="mt-3">Password</label>
                <input type="password" name="password" class="form-control" required>

                <label class="mt-3">Nama</label>
                <input type="text" name="nama" class="form-control" required>

                <label class="mt-3">Kelamin</label>
                <select name="kelamin" class="form-control" required>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>

                <label class="mt-3">Alamat</label>
                <textarea name="alamat" class="form-control"></textarea>

                <label class="mt-3">Level</label>
                <select name="level" class="form-control" required>
                    <option value="admin">admin</option>
                    <option value="petugas">petugas</option>
                </select>

                <button class="btn btn-primary mt-3">Simpan</button>
            </form>
        </div>
    </div>
</div>
@endsection
