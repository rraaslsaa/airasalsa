@extends('layout.app')

@section('content')
<div class="container mt-4">
    <div class="card">
        <div class="card-header">Tambah Jenis Pelanggaran</div>
        <div class="card-body">
            <form action="{{ route('jenis.store') }}" method="POST">
                @csrf

                <label>Jenis</label>
                <input type="text" name="jenis" class="form-control" required>

                <label class="mt-3">Keterangan</label>
                <textarea name="keterangan" class="form-control"></textarea>

                <label class="mt-3">Poin</label>
                <input type="number" name="poin" class="form-control" required>

                <button class="btn btn-primary mt-3">Simpan</button>
            </form>
        </div>
    </div>
</div>
@endsection
