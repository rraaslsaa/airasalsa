@extends('layout.app')

@section('content')
<div class="container mt-4">

    <div class="card">
        <div class="card-header">Edit Jenis Pelanggaran</div>
        <div class="card-body">

            <form action="{{ route('jenis.update', $data->id) }}" method="POST">
                @csrf @method('PUT')

                <label>Jenis Pelanggaran</label>
                <input type="text" name="jenis" value="{{ $data->jenis }}" class="form-control">

                <label class="mt-3">Keterangan</label>
                <textarea name="keterangan" class="form-control">{{ $data->keterangan }}</textarea>

                <label class="mt-3">Poin</label>
                <input type="number" name="poin" value="{{ $data->poin }}" class="form-control">

                <button class="btn btn-primary mt-3">Update</button>
            </form>

        </div>
    </div>

</div>
@endsection
