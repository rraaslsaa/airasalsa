@extends('layout.app')

@section('content')
<div class="container mt-4">

    <a href="{{ route('jenis.create') }}" class="btn btn-primary mb-3">+ Tambah Jenis Pelanggaran</a>

    <div class="card">
        <div class="card-header">Data Jenis Pelanggaran</div>
        <div class="card-body">

            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Jenis</th>
                    <th>Keterangan</th>
                    <th>Poin</th>
                    <th>Aksi</th>
                </tr>

                @foreach($data as $j)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $j->jenis }}</td>
                    <td>{{ $j->keterangan }}</td>
                    <td>{{ $j->poin }}</td>
                    <td>
                        <a href="{{ route('jenis.edit', $j->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('jenis.destroy', $j->id) }}" method="POST" class="d-inline">
                            @csrf @method('DELETE')
                            <button class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
                @endforeach

            </table>

        </div>
    </div>

</div>
@endsection
