<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\KelasController;
use App\Http\Controllers\SiswaController;
use App\Http\Controllers\JenisController;
use App\Http\Controllers\PelanggaranController;
use App\Http\Controllers\UserController;


// =========================
// AUTH
// =========================
Route::get('/login', [AuthController::class, 'index'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');


// =========================
// HALAMAN UTAMA SETELAH LOGIN
// =========================
Route::middleware(['ceklogin'])->group(function () {

    // Langsung masuk ke halaman pelanggaran (bukan dashboard)
    Route::get('/', function() {
        return redirect('/pelanggaran');
    })->name('home');

    // CRUD
    Route::resource('/kelas', KelasController::class);
    Route::resource('/siswa', SiswaController::class);
    Route::resource('/jenis', JenisController::class);
    Route::resource('/pelanggaran', PelanggaranController::class);
    Route::resource('/user', UserController::class);
});
